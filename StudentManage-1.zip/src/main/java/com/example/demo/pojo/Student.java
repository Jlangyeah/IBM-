package com.example.demo.pojo;

import org.yaml.snakeyaml.constructor.Construct;

public class Student {
	private Integer id;
	private Integer stunum;
    private String name;
    private String birth;
    private String gender;
    private String phonenum;
    private String classnum;
    private String dept;
	public Student(Integer id, Integer stunum, String name, String birth, String gender, String phonenum,
			String classnum, String dept) {
		super();
		this.id = id;
		this.stunum = stunum;
		this.name = name;
		this.birth = birth;
		this.gender = gender;
		this.phonenum = phonenum;
		this.classnum = classnum;
		this.dept = dept;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getStunum() {
		return stunum;
	}
	public void setStunum(Integer stunum) {
		this.stunum = stunum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPhonenum() {
		return phonenum;
	}
	public void setPhonenum(String phonenum) {
		this.phonenum = phonenum;
	}
	public String getClassnum() {
		return classnum;
	}
	public void setClassnum(String classnum) {
		this.classnum = classnum;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	
   }
