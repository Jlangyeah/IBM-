package com.example.demo.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo.pojo.Student;

@Mapper
public interface StudentDao {
	//全查学生信息
    public List<Student>selectAll();
    //根据ID删除学生信息
    public void deleteById(Integer id);
    //添加学生信息
    public void insertStudent(Student student);
    //根据id查询学生信息
    public Student selectById(Integer id);
    //修改学生信息
    public void updateStudent(Student student);
}
