package com.example.demo.service;

import java.util.List;

import javax.management.RuntimeErrorException;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.StudentDao;
import com.example.demo.pojo.Student;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {
	@Autowired
	private StudentDao sd;

	@Override
	public List<Student> queryAll() {
		// TODO Auto-generated method stub
		return sd.selectAll();
	}
	
	@Override
	public void removeById(Integer id) {
		try {
			sd.deleteById(id);
		}catch (Exception e) {
			// TODO: handle exception
			throw new RuntimeException("根据id删除异常");
		}
	}
	
	@Override
	public void addStudent(Student student) {
		try {
			sd.insertStudent(student);
		}catch(Exception e) {
			throw new RuntimeException("添加异常");
		}
	}
	
    @Override
    public Student queryById(Integer id) {
    	return sd.selectById(id);
    }

	@Override
	public void changeStudent(Student student) {
		// TODO Auto-generated method stub
		try {
			sd.updateStudent(student);
		}catch (Exception e) {
			// TODO: handle exception
			throw new RuntimeException("修改数据异常");
		}
	}
    
    
}
