package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.pojo.Student;
import com.example.demo.service.StudentService;

@RestController
@RequestMapping("/student")
public class StudentController {
	@Autowired
	private StudentService ss;
	//全查
	@RequestMapping("/queryAll")
public String queryAll(Model model) {
		List<Student> list = ss.queryAll();
		//存入model中
		model.addAttribute("list",list);
		//控制跳转
		return "showAll";
		}
	
	//根据id删除学生信息
	@RequestMapping("removeById")
	public String removeById(Integer id) {
		try {
			ss.removeById(id);
			return "redirect:/student/queryAll";
		}catch (Exception e) {
			// TODO: handle exception
			return "error";
		}
	}
	
	//添加学生信息
	@RequestMapping("addStudent")
	public String addStudent(Student student) {
		try {
			ss.addStudent(student);
			return "redirect:/student/queryAll";
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return "error";
		}
	}
	
	//根据id查询学生信息
	@RequestMapping("queryById")
	public String queryById(Integer id, ModelMap mm){
		Student student = ss.queryById(id);
		mm.addAttribute("student",student);
		//跳转到修改页面，进行数据回显
		return "update";
	}
	
	//修改学生信息
	@RequestMapping("changeStudent")
	public String changeStudent(Student student) {
		try {
			ss.changeStudent(student);
			return "redirect:/student/queryAll";
		} catch (Exception e) {
			// TODO: handle exception
			return "error";
		}
	}
}
