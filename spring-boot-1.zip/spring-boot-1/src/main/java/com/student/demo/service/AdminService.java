package com.student.demo.service;

import static com.student.demo.utils.StaticUtil.Pagination;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.demo.mapper.AdminDao;
import com.student.demo.model.Admin;

//@Service("adminService")
@Service
public class AdminService {
	@Autowired
	AdminDao adminDao;

	public boolean checkId(String id) {
		return adminDao.checkId(id);
	}

	public int addAdmin(Admin admin) {
		if (checkId(admin.getId()))
			return -1;

		adminDao.addAdmin(admin);
		return 1;
	}

	public boolean login(String id, String password) {
		return adminDao.login(id, password);
	}

	public int updateAdmin(String id, String name, String phone, String password) {
		Admin admin = new Admin();
		admin.setId(id);
		admin.setName(name);
		admin.setPassword(password);
		admin.setPhone(phone);
		return adminDao.updateAdmin(admin);
	}

	public Admin getAdminById(String id) {
		return adminDao.getAdminById(id);
	}

	public List<Admin> getAdmin(int page) {
		int a = (page - 1) * Pagination;
		return adminDao.getAdmin(a, Pagination);
	}

}
