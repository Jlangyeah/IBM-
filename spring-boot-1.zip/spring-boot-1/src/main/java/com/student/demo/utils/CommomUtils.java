package com.student.demo.utils;




import java.text.SimpleDateFormat;
import java.util.Date;


public class CommomUtils {

    public static String getCurrentTime() {
        Date day = new Date();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return df.format(day);
    }
    public static String getNotNullString(String str){
        return str==null?"":str;
    }

}
