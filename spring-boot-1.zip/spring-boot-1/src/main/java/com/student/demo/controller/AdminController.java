package com.student.demo.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.student.demo.model.Admin;
import com.student.demo.service.AdminService;
import com.student.demo.utils.ReturnUtil;

@CrossOrigin
@Controller
@RequestMapping(value = "/student/user", method = RequestMethod.POST)
//@RequestMapping("/user")
public class AdminController {

	@Autowired
	AdminService adminService;

	// 用户注册 , produces = "text/html;charset=UTF-8
	@RequestMapping(value = "/register")
//	@RequestMapping("/register")
	@ResponseBody
	public String register(HttpSession session, String id, String name, String phone, String password) {
		if (id == null || id.trim().length() == 0 || password == null || password.trim().length() == 0)
			return ReturnUtil.adminReturn("用户名或密码不能为空", "0");
		Admin admin = new Admin();
		admin.setId(id);
		admin.setName(name);
		admin.setPhone(phone);
		admin.setPassword(password);
		int result = adminService.addAdmin(admin);
		if (result == -1)
			return ReturnUtil.adminReturn("用户名已存在", "0");
		else if (result > 0)
			return ReturnUtil.adminReturn("用户注册成功", "1");
		else
			return ReturnUtil.adminReturn("用户注册失败", "0");
	}

	// 用户登录
	@RequestMapping(value = "/login")
	@ResponseBody
	public String login(HttpSession session, String id, String password) {

		if (id == null || id.trim().length() == 0 || password == null || password.trim().length() == 0)
			return ReturnUtil.adminReturn2("用户名或者密码为空", "0", id, password);

		boolean result = adminService.login(id, password);

		if (result)
			return ReturnUtil.adminReturn2("登录成功", "1", id, password);
		else
			return ReturnUtil.adminReturn2("用户名或者密码错误", "0", id, password);
	}

	// 修改用户信息
	@RequestMapping(value = "/modify")
	@ResponseBody
	public String modify(HttpSession session, String id, String name, String phone, String password) {

		if (id == null || id.trim().length() == 0)
			return ReturnUtil.adminReturn3("用户名不能为空", "0", id, name, phone, password);

		if ((name == null || name.trim().length() == 0) && (phone == null || phone.trim().length() == 0)
				&& (password == null || password.trim().length() == 0)) {
			Admin admin = adminService.getAdminById(id);
			if (admin == null) {
				return ReturnUtil.adminReturn3("用户名不存在", "0", id, name, phone, password);
			} else
				return ReturnUtil.adminReturn3("修改成功", "1", admin.getId(), admin.getName(), admin.getPhone(),
						admin.getPassword());
		}

		int result = adminService.updateAdmin(id, name, phone, password);
//返回信息是否修改成功
		if (result > 0) {
			Admin admin = adminService.getAdminById(id);
			return ReturnUtil.adminReturn3("修改成功", "1", admin.getId(), admin.getName(), admin.getPhone(),
					admin.getPassword());
		} else
			return ReturnUtil.adminReturn3("修改失败", "0", id, name, phone, password);
	}

}
