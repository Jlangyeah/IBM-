package com.student.demo.utils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

//图片上传
public class FileUtil {

	public static List<String> uploadFile(HttpServletRequest request, String stunum) {

		List<String> list = new ArrayList<>();
		String flag = "";
		// 创建一个通用的多部分解析器
//      MultipartResolver resolver = new CommonsMultipartResolver(request.getSession().getServletContext());
//      MultipartHttpServletRequest multipartRequest = resolver.resolveMultipart(request);
		CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver(
				request.getSession().getServletContext());
		// 判断 request 是否有文件上传,即多部分请求
		if (multipartResolver.isMultipart(request)) {
			// 转换成多部分request
			MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;
			// 取得request中的所有文件名
			Iterator<String> iter = multiRequest.getFileNames();

			String uploadPath = StaticUtil.UploadPath;

			File mfile = new File(uploadPath);
			if (!mfile.exists()) {
				mfile.mkdirs();
			}

			while (iter.hasNext()) {
				// 取得上传文件
				MultipartFile file = multiRequest.getFile(iter.next());
				if (file != null) {

//                  if (file.getSize() > 1048576) {
//                      list.add( "0");
//                      list.add("文件大小不能超过1mb");
//                      break;
//                  }

					// 取得当前上传文件的文件名称
					String myFileName = file.getOriginalFilename();
					// 如果名称不为“”,说明该文件存在，否则说明该文件不存在
					if (!"".equals(myFileName.trim())) {
						String storeName = "";
						if (myFileName.contains(".")) {
							storeName = stunum + myFileName.substring(myFileName.indexOf("."));
						} else {
							storeName = stunum + ".jpg";
						}

						File uploadFile = new File(uploadPath + storeName);

						try {
							FileCopyUtils.copy(file.getBytes(), uploadFile);
							list.add("1");
							list.add(uploadPath + storeName);

						} catch (IOException e) {
							list.add("0");
							e.printStackTrace();
						}

					}
				}
				break;
			}

		}

		return list;
	}

	/**
	 *
	 * @param path
	 */
	public static void deleteFile(String path) {
		File file = new File(path);
		if (file.exists() && file.isFile()) {
			file.delete();
		}
	}
}