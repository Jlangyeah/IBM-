package com.student.demo.utils;


import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import sun.misc.BASE64Encoder;

import javax.imageio.stream.FileImageOutputStream;
import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

public class FileUtil {


    public static List<String> uploadFile(HttpServletRequest request, String stunum) {

        List<String> list = new ArrayList<>();
        String flag = "";
        //����һ��ͨ�õĶಿ�ֽ�����
//        MultipartResolver resolver = new CommonsMultipartResolver(request.getSession().getServletContext());
//        MultipartHttpServletRequest multipartRequest = resolver.resolveMultipart(request);

        CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver(request.getSession().getServletContext());
        //�ж� request �Ƿ����ļ��ϴ�,���ಿ������
        if (multipartResolver.isMultipart(request)) {
            //ת���ɶಿ��request
            MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;
            //ȡ��request�е������ļ���
            Iterator<String> iter = multiRequest.getFileNames();



            String uploadPath = StaticUtil.UploadPath;

            File mfile = new File(uploadPath);
            if (!mfile.exists()) {
                mfile.mkdirs();
            }

            while (iter.hasNext()) {
                //ȡ���ϴ��ļ�
                MultipartFile file = multiRequest.getFile(iter.next());
                if (file != null) {

//                    if (file.getSize() > 1048576) {
//                        list.add( "0");
//                        list.add("�ļ���С���ܳ���1mb");
//                        break;
//                    }

                    //ȡ�õ�ǰ�ϴ��ļ����ļ�����
                    String myFileName = file.getOriginalFilename();
                    //������Ʋ�Ϊ����,˵�����ļ����ڣ�����˵�����ļ�������
                    if (!"".equals(myFileName.trim())) {
                        String storeName = "";
                        if (myFileName.contains(".")) {
                            storeName = stunum + myFileName.substring(myFileName.indexOf("."));
                        } else {
                            storeName = stunum + ".jpg";
                        }

                        File uploadFile = new File(uploadPath + storeName);


                        try {
                            FileCopyUtils.copy(file.getBytes(), uploadFile);
                            list.add("1");
                            list.add(uploadPath + storeName);

                        } catch (IOException e) {
                            list.add("0");
                            e.printStackTrace();
                        }


                    }
                }
                break;
            }

        }

        return list;
    }

    /**
     *
     * @param path
     */
    public static void deleteFile(String path){
        File file = new File(path);
        if (file.exists() && file.isFile()){
            file.delete();
        }
    }
}