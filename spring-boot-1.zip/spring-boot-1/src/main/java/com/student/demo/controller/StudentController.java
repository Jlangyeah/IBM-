package com.student.demo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

//import com.mysql.jdbc.StringUtils;
import com.student.demo.model.Student;
import com.student.demo.service.StudentService;
import com.student.demo.utils.FileUtil;
import com.student.demo.utils.ReturnUtil;

@CrossOrigin
@Controller
//@RequestMapping(value = "/student/student", method = RequestMethod.POST)
@RequestMapping("/student")
public class StudentController {

	@Autowired
	StudentService studentService;

	@RequestMapping(value = "/add")
	@ResponseBody
	public String add(HttpSession session, String name, String stunum, String birth, String gender, String clazz,
			String dept, String phone, String photo) {
		if (stunum == null || stunum.trim().length() == 0)
			return ReturnUtil.studentReturn("学号不能为空", "0", name, stunum, birth, gender, clazz, dept, phone, photo);

		int result = studentService.addStudent(name, stunum, birth, gender, clazz, dept, phone, photo);
		if (result == -1)
			return ReturnUtil.studentReturn("学生学号已存在", "0", name, stunum, birth, gender, clazz, dept, phone, photo);
		else if (result > 0)
			return ReturnUtil.studentReturn("新增成功", "1", name, stunum, birth, gender, clazz, dept, phone, photo);
		else
			return ReturnUtil.studentReturn("新增失败", "0", name, stunum, birth, gender, clazz, dept, phone, photo);
	}

	@RequestMapping(value = "/modify")
	@ResponseBody
	public String modify(HttpSession session, String name, String stunum, String birth, String gender, String clazz,
			String dept, String phone, String photo) {

		if (stunum == null || stunum.trim().length() == 0)
			return ReturnUtil.studentReturn("学号为空", "0", name, stunum, birth, gender, clazz, dept, phone, photo);

		if ((birth == null || birth.trim().length() == 0) && (gender == null || gender.trim().length() == 0)
				&& (clazz == null || clazz.trim().length() == 0) && (dept == null || dept.trim().length() == 0)
				&& (name == null || name.trim().length() == 0)) {
			Student student = studentService.getStudentByNum(stunum);
			if (student == null) {
				return ReturnUtil.studentReturn("学号不存在", "0", name, stunum, birth, gender, clazz, dept, phone, photo);
			} else
				return ReturnUtil.studentReturn("修改成功", "1", student.getName(), stunum, student.getBirth(),
						student.getGender(), student.getClazz(), student.getDept(), student.getPhone(),
						student.getPhoto());
		}

		int result = studentService.updateStudent(name, stunum, birth, gender, clazz, dept, phone, photo);

		if (result > 0) {
			Student student = studentService.getStudentByNum(stunum);
			return ReturnUtil.studentReturn("修改成功", "1", student.getName(), stunum, student.getBirth(),
					student.getGender(), student.getClazz(), student.getDept(), student.getPhone(), student.getPhoto());
		} else
			return ReturnUtil.studentReturn("修改失败", "0", name, stunum, birth, gender, clazz, dept, phone, photo);
	}

	@RequestMapping(value = "/delete")
	@ResponseBody
	public String delete(HttpSession session, String stunum) {

		if (stunum == null || stunum.trim().length() == 0)
			return ReturnUtil.adminReturn("学号不能为空", "0");

		int result = studentService.delete(stunum);

		if (result > 0)
			return ReturnUtil.adminReturn("删除成功", "0");
		else
			return ReturnUtil.adminReturn("删除失败", "0");
	}

//	@RequestMapping("/query")
//	@ResponseBody
//	public List<Student> query() {
	// System.out.println("xingming:");
//		System.out.println("xingming:" + name);
//		List<Student> studentList;
//		if (StringUtils.isBlank(name) && StringUtils.isBlank(stunum) && StringUtils.isBlank(birth)
//				&& StringUtils.isBlank(clazz) && StringUtils.isBlank(gender) && StringUtils.isBlank(dept)
//				&& StringUtils.isBlank(phone)) {
//			studentList = studentService.getStudent();
//		} else
//			studentList = studentService.getStudentByWord(name, stunum, birth, gender, clazz, dept, phone, 0);
//
//		return ReturnUtil.studentReturn2("查询成功", "1", studentList);
//		return studentService.getStudent();
//	}

	@RequestMapping(value = "/query")
	@ResponseBody
	public String query(HttpSession session, String name, String stunum, String birth, String clazz, String gender,
			String dept, String phone, Integer page) {
		if (page == null) {
			page = 1;
		}

		System.out.println("xingming:" + name);
		List<Student> studentList;
		if (StringUtils.isBlank(name) && StringUtils.isBlank(stunum) && StringUtils.isBlank(birth)
				&& StringUtils.isBlank(clazz) && StringUtils.isBlank(gender) && StringUtils.isBlank(dept)
				&& StringUtils.isBlank(phone)) {
			studentList = studentService.getStudent();
		} else
//		if (StringUtils.isBlank(name + stunum + birth + clazz + gender + dept + phone)) {
//			studentList = studentService.getStudent(page);
//		} else
			studentList = studentService.getStudentByWord(name, stunum, birth, gender, clazz, dept, phone, page);

		System.out.println("studentList:" + studentList);
		return ReturnUtil.studentReturn2("查询成功", "1", studentList);
	}

	// 新增参数page，需要传递
	@RequestMapping(value = "/statistics")
	@ResponseBody
	public String statistics(HttpSession session, String name, String stunum, String birth, String clazz, String gender,
			String dept, String phone, int page) {

		List<Student> studentList = studentService.getStudentByWord(name, stunum, birth, gender, clazz, dept, phone,
				page);

		return ReturnUtil.studentReturn3(studentList);
	}

//, produces = "text/html;charset=UTF-8"
	@RequestMapping(value = "/upload")
	@ResponseBody
	public String upload(HttpServletRequest request, String stunum) {

		if (stunum == null || stunum.trim().length() == 0)
			return ReturnUtil.adminReturn("学号不能为空", "0");

		List list = FileUtil.uploadFile(request, stunum);

		if (list.size() != 2)
			return ReturnUtil.adminReturn("上传失败", "0");

		String code = (String) list.get(0);
		if ("0".equals(code))
			return ReturnUtil.adminReturn("上传失败,原因：" + list.get(1), "0");

		Student student = studentService.getStudentByNum(stunum);
		if (student == null || student.getStunum() == null)
			return ReturnUtil.adminReturn("学号不存在", "0");

		String photo = (String) list.get(1);
		student.setPhoto(photo);
		studentService.updateStudent(student);

		return ReturnUtil.studentReturn("上传成功", "1", student);

	}

}
