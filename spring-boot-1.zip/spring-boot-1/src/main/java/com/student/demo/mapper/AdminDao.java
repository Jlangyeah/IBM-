package com.student.demo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.student.demo.model.Admin;

public interface AdminDao {

	public boolean checkId(String id);

	public int addAdmin(Admin admin);

	public boolean login(@Param("id") String id, @Param("password") String password);

	public int updateAdmin(Admin admin);

	public Admin getAdminById(String id);

	public List<Admin> getAdmin(@Param("b") int b, @Param("e") int e);

}
