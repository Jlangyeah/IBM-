package com.student.demo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.student.demo.model.Admin;

public interface AdminDao {

	public boolean checkId(String id);

	public int addAdmin(Admin admin);// 注册用户信息

	public boolean login(@Param("id") String id, @Param("password") String password);// 登陆用户

	public int updateAdmin(Admin admin);// 更改用户信息

	public Admin getAdminById(String id);// 获取用户

	public List<Admin> getAdmin(@Param("b") int b, @Param("e") int e);// 获取用户信息

}
