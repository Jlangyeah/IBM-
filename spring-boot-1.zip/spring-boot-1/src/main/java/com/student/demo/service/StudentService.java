package com.student.demo.service;

import static com.student.demo.utils.StaticUtil.Pagination;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.demo.mapper.StudentDao;
import com.student.demo.model.Student;

//@Service("userService")
@Service
public class StudentService {
	@Autowired
	StudentDao studentDao;

	public boolean checkStuNum(String stunum) {
		return studentDao.checkStuNum(stunum);
	}

	// 学生信息添加
	public int addStudent(String name, String stunum, String birth, String gender, String clazz, String dept,
			String phone, String photo) {
		if (checkStuNum(stunum))
			return -1;
		Student student = new Student();
		student.setBirth(birth);
		student.setClazz(clazz);
		student.setDept(dept);
		student.setName(name);
		student.setStunum(stunum);
		student.setGender(gender);
		student.setPhone(phone);
		student.setPhoto(photo);
		return studentDao.addStudent(student);
	}

	// 学生信息修改
	public int updateStudent(String name, String stunum, String birth, String gender, String clazz, String dept,
			String phone, String photo) {
		Student student = new Student();
		student.setBirth(birth);
		student.setClazz(clazz);
		student.setDept(dept);
		student.setName(name);
		student.setStunum(stunum);
		student.setGender(gender);
		student.setPhone(phone);
		student.setPhoto(photo);
		return studentDao.updateStudent(student);
	}

	public int updateStudent(Student student) {
		return studentDao.updateStudent(student);
	}

	public Student getStudentByNum(String stunum) {
		return studentDao.getStudentByNum(stunum);
	}

	public List<Student> getStudent(int page) {
		int a = (page - 1) * Pagination;
		return studentDao.getStudent(a, Pagination);
	}

	public List<Student> getStudent() {
		return studentDao.getStudent(0, 99999);
	}

	// 学生信息查询
	public List<Student> getStudentsByWord(Student student) {
		return studentDao.getStudentsByWord(student);
	}

	public List<Student> getStudentByWord(String name, String stunum, String birth, String gender, String clazz,
			String dept, String phone, int page) {
		int a = (page - 1) * Pagination;
		return studentDao.getStudentByWord(name, stunum, birth, gender, clazz, dept, phone, a, Pagination);
	}

	// 学生信息删除
	public int delete(String stunum) {
		return studentDao.delete(stunum);
	}

	// 统计
	public Map<String, Long> getTotal() {
		Map<String, Long> map = new HashMap();
		List<Map<String, Long>> deptList = studentDao.getDeptTotal();
		for (Map<String, Long> dept : deptList) {
			map.put(dept.get("dept") + "", dept.get("deptNum"));
		} // {"ji":1,"su":7}

		long totalNum = 0;
		List<Map<String, Long>> genderList = studentDao.getGenderTotal();
		for (Map<String, Long> dept : genderList) {

			totalNum += dept.get("genderNum");
			map.put(dept.get("gender") + "", dept.get("genderNum"));
		} // {"ji":1,"su":7}

		List<Map<String, Long>> claszzList = studentDao.getClazzTotal();
		for (Map<String, Long> dept : claszzList) {
			map.put(dept.get("clazz") + "", dept.get("clazzNum"));
		} // {"ji":1,"su":7}
			// {"ji":1,"su":7,"b1":2,"b2":3}

		map.put("total", totalNum);
		return map;
	}
}
