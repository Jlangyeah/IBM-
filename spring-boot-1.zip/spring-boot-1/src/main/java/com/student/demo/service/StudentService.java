package com.student.demo.service;

import static com.student.demo.utils.StaticUtil.Pagination;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.demo.mapper.StudentDao;
import com.student.demo.model.Student;

//@Service("userService")
@Service
public class StudentService {
	@Autowired
	StudentDao studentDao;

	public boolean checkStuNum(String stunum) {
		return studentDao.checkStuNum(stunum);
	}

	public int addStudent(String name, String stunum, String birth, String gender, String clazz, String dept,
			String phone, String photo) {
		if (checkStuNum(stunum))
			return -1;
		Student student = new Student();
		student.setBirth(birth);
		student.setClazz(clazz);
		student.setDept(dept);
		student.setName(name);
		student.setStunum(stunum);
		student.setGender(gender);
		student.setPhone(phone);
		student.setPhoto(photo);
		return studentDao.addStudent(student);
	}

	public int updateStudent(String name, String stunum, String birth, String gender, String clazz, String dept,
			String phone, String photo) {
		Student student = new Student();
		student.setBirth(birth);
		student.setClazz(clazz);
		student.setDept(dept);
		student.setName(name);
		student.setStunum(stunum);
		student.setGender(gender);
		student.setPhone(phone);
		student.setPhoto(photo);
		return studentDao.updateStudent(student);
	}

	public int updateStudent(Student student) {
		return studentDao.updateStudent(student);
	}

	public Student getStudentByNum(String stunum) {
		return studentDao.getStudentByNum(stunum);
	}

	public List<Student> getStudent(int page) {
		int a = (page - 1) * Pagination;
		return studentDao.getStudent(a, Pagination);
	}

	public List<Student> getStudent() {
		return studentDao.getStudent(0, 99999);
	}

	public List<Student> getStudentByWord(String name, String stunum, String birth, String gender, String clazz,
			String dept, String phone, int page) {
		int a = (page - 1) * Pagination;
		return studentDao.getStudentByWord(name, stunum, birth, gender, clazz, dept, phone, a, Pagination);
	}

	public int delete(String stunum) {
		return studentDao.delete(stunum);
	}
}
