package com.student.demo.utils;




import static com.student.demo.utils.CommomUtils.getNotNullString;

import java.util.List;

import com.student.demo.model.Student;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;



public class ReturnUtil {

    public static String adminReturn(String msg,String code){
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("msg",msg);
        jsonObject.put("code",code);
        return jsonObject.toString();
    }

    public static String adminReturn2(String msg,String code,String id,String password){
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("msg",msg);
        jsonObject.put("code",code);

        JSONObject jsonObject2 = new JSONObject();
        jsonObject2.put("id",getNotNullString(id));
        jsonObject2.put("password",getNotNullString(password));
        jsonObject.put("result",jsonObject2);
        return jsonObject.toString();
    }

    public static String adminReturn3(String msg,String code,String id,
                                      String name,String phone,String password){
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("msg",msg);
        jsonObject.put("code",code);

        JSONObject jsonObject2 = new JSONObject();
        jsonObject2.put("id",id);
        jsonObject2.put("password",getNotNullString(password));
        jsonObject2.put("name",getNotNullString(name));
        jsonObject2.put("phone",getNotNullString(phone));
        jsonObject.put("result",jsonObject2);
        return jsonObject.toString();
    }

    public static String studentReturn(String msg,String code,
                                       String name, String stunum,
                                       String birth, String gender,
                                       String clazz, String dept, String phone){
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("msg",msg);
        jsonObject.put("code",code);

        JSONObject jsonObject2 = new JSONObject();
        jsonObject2.put("name",getNotNullString(name));
        jsonObject2.put("stunum",getNotNullString(stunum));
        jsonObject2.put("birth",getNotNullString(birth));
        jsonObject2.put("gender",getNotNullString(gender));
        jsonObject2.put("clazz",getNotNullString(clazz));
        jsonObject2.put("dept",getNotNullString(dept));
        jsonObject2.put("phone",getNotNullString(phone));
        jsonObject.put("result",jsonObject2);
        return jsonObject.toString();
    }

    public static String studentReturn2(String msg, String code,
                                        List<Student> students){
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("msg",msg);
        jsonObject.put("code",code);

        JSONArray jsonArray = new JSONArray();
        for (Student s : students){
            JSONObject jsonObject2 = new JSONObject();
            jsonObject2.put("name",getNotNullString(s.getName()));
            jsonObject2.put("stunum",getNotNullString(s.getStunum()));
            jsonObject2.put("birth",getNotNullString(s.getBirth()));
            jsonObject2.put("gender",getNotNullString(s.getGender()));
            jsonObject2.put("clazz",getNotNullString(s.getClazz()));
            jsonObject2.put("dept",getNotNullString(s.getDept()));
            jsonObject2.put("phone",getNotNullString(s.getPhone()));
            jsonArray.add(jsonObject2);
        }

        jsonObject.put("result",jsonArray);
        return jsonObject.toString();
    }

    public static String studentReturn3(List<Student> students){
        JSONObject jsonObject = new JSONObject();
        JSONArray jsonArray = new JSONArray();
        for (Student s : students){
            JSONObject jsonObject2 = new JSONObject();
            jsonObject2.put("name",getNotNullString(s.getName()));
            jsonObject2.put("stunum",getNotNullString(s.getStunum()));
            jsonObject2.put("birth",getNotNullString(s.getBirth()));
            jsonObject2.put("gender",getNotNullString(s.getGender()));
            jsonObject2.put("clazz",getNotNullString(s.getClazz()));
            jsonObject2.put("dept",getNotNullString(s.getDept()));
            jsonObject2.put("phone",getNotNullString(s.getPhone()));
            jsonArray.add(jsonObject2);
        }

        jsonObject.put("result",jsonArray);
        return jsonObject.toString();
    }
}
