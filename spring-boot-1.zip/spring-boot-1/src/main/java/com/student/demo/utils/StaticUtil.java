package com.student.demo.utils;



public class StaticUtil {

    //分页数
    public static final int Pagination = 10;
}
