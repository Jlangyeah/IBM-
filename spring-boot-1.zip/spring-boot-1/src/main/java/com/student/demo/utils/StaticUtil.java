package com.student.demo.utils;

public class StaticUtil {

	// 分页数
	public static final int Pagination = 10;

	// 保存图片的路径
	//
	public static final String UploadPath = "D:/photo/";
}
