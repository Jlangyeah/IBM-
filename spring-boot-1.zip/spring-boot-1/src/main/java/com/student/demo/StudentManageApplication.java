package com.student.demo;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan(basePackages = "com.student.demo.mapper")
public class StudentManageApplication

{
	public static void main(String[] args)

	{
		SpringApplication.run(StudentManageApplication.class, args);

	}

}
