package com.student.demo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.student.demo.model.Student;

public interface StudentDao {

	boolean checkStuNum(String stunum);

	int addStudent(Student user);// 添加学生信息

	int updateStudent(Student user);// 更新学生信息

	Student getStudentByNum(String stunum);// 根据学号查询

	List<Student> getStudent(@Param("b") int b, @Param("e") int e);

	int delete(String stunum);// 删除学生信息

	List<Student> getStudentByWord(@Param("name") String name, @Param("stunum") String stunum,
			@Param("birth") String birth, @Param("gender") String gender, @Param("clazz") String clazz,
			@Param("dept") String dept, @Param("phone") String phone, @Param("b") int b, @Param("e") int e);
}
