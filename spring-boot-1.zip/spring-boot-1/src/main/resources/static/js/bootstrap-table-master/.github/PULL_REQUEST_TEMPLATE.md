**Bug fix?**
<!-- yes/no -->

**New Feature?**
<!-- yes/no -->

**Resolve an issue?**
<!-- Please prefix each issue number with  "Fix #"  (e.g. Fix #200)  -->

**Example(s)?**
<!-- Please use our online Editor (https://live.bootstrap-table.com/) to create example(s) (Before and after your changes).
     On our Wiki (https://github.com/wenzhixin/bootstrap-table/wiki/Online-Editor-Explanation) you can read how to use the editor.-->
     

<!-- Love bootstrap-table? Please consider supporting our collective:
👉  https://opencollective.com/bootstrap-table/donate -->